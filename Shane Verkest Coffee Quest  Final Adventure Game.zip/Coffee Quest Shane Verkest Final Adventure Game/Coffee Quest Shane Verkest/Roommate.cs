﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Coffee_Quest_Shane_Verkest
{
    public class Roommate
    {
        protected string Name;
        protected string Major;
        protected string Job;
        protected int BankAccount;
        protected int CaffeineLevel;
        protected int MuscleLevel;

        public void AboutRoommate()
        {
            Console.WriteLine(this.Name + " is a " + this.Major + " major. His currently works as a " + this.Job + ". He has $" + this.BankAccount + " in his bank account.");
        }

        public Roommate(string _Name, string _Major, string _Job, int BankAccount)
        {
            this.Name = _Name;
            this.Major = _Major;
            this.Job = _Job;
            this.BankAccount = BankAccount;

        }
    }
}
