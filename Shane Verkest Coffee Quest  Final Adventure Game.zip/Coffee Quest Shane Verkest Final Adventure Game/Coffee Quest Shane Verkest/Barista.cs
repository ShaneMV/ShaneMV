﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Coffee_Quest_Shane_Verkest
{
    public class Barista : Roommate
    {
        public Barista(string _Name, string _Major, string _Job, int BankAccount) : base(_Name, _Major, _Job, BankAccount)
        {
            this.Name = _Name;
            this.Major = _Major;
            this.Job = _Job;
            this.BankAccount = BankAccount;
            this.CaffeineLevel = 1000;
        }
        public static void TakeOrder()
        {
            Console.Clear();
            Console.WriteLine("WELCOME TO THE COFFEE SHOP");
            Console.WriteLine("--------------------------");
            Coffee.ReadMenu();
            Console.WriteLine("--------------------------");
            Console.WriteLine("Your current bank account is $" + Player.PlayerMoney);
            Console.WriteLine("What would you like today?");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            string input = Console.ReadLine();
            if (input == "regular coffee")
            {
                Console.Clear();
                Player.PlayerTotal = Player.PlayerMoney - Coffee.CoffeePrice[0];
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Okay, you have ordered a ");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(input);
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("! Your total is $");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(Coffee.CoffeePrice[0]);
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\n\nPress enter to enjoy your drink...");
                Console.ReadLine();
            }
            else if (input == "mocha latte")
            {
                Console.Clear();
                Player.PlayerTotal = Player.PlayerMoney - Coffee.CoffeePrice[1];
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Okay, you have ordered a ");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(input);
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("! Your total is $");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(Coffee.CoffeePrice[1]);
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\n\nPress enter to enjoy your drink...");
                Console.ReadLine();
            }
            else if (input == "caramel frappe")
            {
                Console.Clear();
                Player.PlayerTotal = Player.PlayerMoney - Coffee.CoffeePrice[2];
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Okay, you have ordered a ");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(input);
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("! Your total is $");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(Coffee.CoffeePrice[2]);
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\n\nPress enter to enjoy your drink...");
                Console.ReadLine();
            }
            else if (input == "unicorn drink")
            {
                Console.Clear();
                Player.PlayerTotal = Player.PlayerMoney - Coffee.CoffeePrice[3];
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("Okay, you have ordered a ");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write(input);
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("! Your total is $");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write(Coffee.CoffeePrice[3]);
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("\n\nPress enter to enjoy your drink...");
                Console.ReadLine();
            }
            else
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Console.WriteLine("Incorrect Input...press enter");
                Console.ReadLine();
                TakeOrder();
            }

        }
    }
}
