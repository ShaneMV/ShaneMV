﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Coffee_Quest_Shane_Verkest
{
    class Game
    {
        public static void StartGame()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(Graphics.title);
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("One Students Journey To Obtain the Bitter Bean!");
            Console.WriteLine("\nPress enter to begin your journey...");
            Console.ReadLine();
            Console.Clear();
        }
        public static void ChoiceOne()
        {
            Console.Clear();
            string input = "";
            Console.WriteLine(Graphics.Room);
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("You awaken in your bed, and look around your messy room. The first thing you notice is the pounding pain \nin your head...a caffeine headache! There’s only one solution: you gotta find a cup of joe fast! \n\nThe first thing you need to do is get out of this room...");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n\nA) Check the door  B) Check the dresser  C) Check your pants  D) Go back to bed");
            input = Console.ReadLine();
            input = input.ToUpper();
            if (input == "A")
            {
                if (Player.Inventory.Contains("Key"))
                {
                    Console.ResetColor();
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Clear();
                    Console.WriteLine("You did it! The door opens...");
                    Console.WriteLine("Press enter to leave...");
                    Console.ReadLine();
                    Foyer();
                }
                else
                {
                    Console.ResetColor();
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Clear();
                    Console.WriteLine("It's locked! Looks like you need a key...");
                    Console.WriteLine("\nPress enter...");
                    Console.ReadLine();
                    ChoiceOne();
                }

            }
            else if (input == "B")
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Player.InventoryAmount++;
                Player.Inventory.Add("Key");
                Console.Write("Underneath the Taco Bell cups and old candy wrappers you found the ");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("door key");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("! \nThis should come in handy...");
                Console.WriteLine("\nPress enter...");
                Console.ReadLine();
                ChoiceOne();
            }
            else if (input == "C")
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Player.InventoryAmount++;
                Player.Inventory.Add("Pack of Gum");
                Console.Write("You found a ");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("pack of gum");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("! Not bad!");
                Console.WriteLine("\nPress enter...");
                Console.ReadLine();
                ChoiceOne();
            }
            else if (input == "D")
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Player.InventoryAmount++;
                Player.Inventory.Add("Espresso Handle");
                Console.Write("Goodness you’re lazy! But what is this...underneath your pillow you find an ");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.Write("espresso handle");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("! \nMaybe that will come in handy later!");
                Console.WriteLine("\nPress enter...");
                Console.ReadLine();
                ChoiceOne();
            }
            else
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Console.WriteLine("Incorrect Input...press enter");
                Console.ReadLine();
                ChoiceOne();
            }
        }
        public static void Foyer()
        {
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            string input = "";
            Console.WriteLine(Graphics.Foyer);
            Console.WriteLine("You enter the foyer and are hit with the immediate smell of sweet caffeine. You’re getting closer. \n\nYou remember your roommate Joe is a barista. How convenient! \n\nHowever, you know for a fact you can make coffee just as good in the kitchen. Where will you go?");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nA) Joes room  B) The kitchen");
            input = Console.ReadLine();
            input = input.ToUpper();
            if(input == "A")
            {
                Joe();
            }
            else if (input == "B")
            {
                Kitchen();
            }
            else
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Console.WriteLine("Incorrect Input...press enter");
                Console.ReadLine();
                Foyer();
            }
        }
        public static void Kitchen()
        {
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.WriteLine(Graphics.Bully);
            Jock Chad = new Jock("Chad", "Business", "Weight Trainer", 15, 100);
            Console.WriteLine("You approach the kitchen...but are suddenly stopped by your Jock roommate Chad!\n\n");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Chad.AboutRoommate();
            Jock.Bully();
            Kitchen2();
            
        }
        public static void Kitchen2()
        {
            
            Console.Clear();
            Console.WriteLine(Graphics.Kitchen);
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("You enter the kitchen! On the counter you see an espresso maker and a coffee maker! \nYou're so close! Where do you look first?");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nA)Counter B)Under the counter C)In the pantry D)Above the fridge");
            string input = "";
            input = Console.ReadLine();
            input = input.ToUpper();
            if (input == "A") 
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Console.WriteLine(Graphics.Counter);
                Console.WriteLine("You see the espresso machine and the coffee maker");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n\nA) Espresso maker  B) Coffee maker");
                string input2 = "";
                input2 = Console.ReadLine();
                input2 = input2.ToUpper();
                if (input2 == "A")
                {
                    if (Player.Inventory.Contains("Espresso Handle"))
                    {
                        if (Player.Inventory.Contains("Mocha Mix"))
                        {
                            Console.ResetColor();
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Clear();
                            Console.WriteLine("You did it! you made mocha espresso!");
                            Console.WriteLine("Press enter to enjoy your drink!");
                            Console.ReadLine();
                        }
                        else if (Player.Inventory.Contains("Caramel Mix"))
                        {
                            Console.ResetColor();
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Clear();
                            Console.WriteLine("You did it! you made caramel espresso!");
                            Console.WriteLine("Press enter to enjoy your drink!");
                            Console.ReadLine();
                        }
                        else if (Player.Inventory.Contains("Vanilla Mix"))
                        {
                            Console.ResetColor();
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Clear();
                            Console.WriteLine("You did it! you made vanilla espresso!");
                            Console.WriteLine("Press enter to enjoy your drink!");
                            Console.ReadLine();
                        }
                        else
                        {
                            Console.ResetColor();
                            Console.ForegroundColor = ConsoleColor.White;
                            Console.Clear();
                            Console.WriteLine("You have the handle, but no mix! Keep looking!");
                            Console.WriteLine("\n\nPress enter...");
                            Console.ReadLine();
                            Kitchen2();
                        }
                    }
                    else
                    {
                        Console.ResetColor();
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Clear();
                        Console.WriteLine("Sorry! You don't have the espresso handle!");
                        Console.WriteLine("\n\nPress enter...");
                        Console.ReadLine();
                        Kitchen2();
                    }
                }
                else if (input2 == "B")
                {
                    if (Player.Inventory.Contains("Mocha Mix"))
                    {
                        Console.ResetColor();
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Clear();
                        Console.WriteLine("You did it! You made mocha coffee!");
                        Console.WriteLine("\nPress enter to enjoy your drink");
                        Console.ReadLine();
                    }
                    else if (Player.Inventory.Contains("Caramel Mix"))
                    {
                        Console.ResetColor();
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Clear();
                        Console.WriteLine("You did it! You made caramel coffee!");
                        Console.WriteLine("\nPress enter to enjoy your drink");
                        Console.ReadLine();
                    }
                    else if (Player.Inventory.Contains("Vanilla Mix"))
                    {
                        Console.ResetColor();
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Clear();
                        Console.WriteLine("You did it! You made vanilla coffee!");
                        Console.WriteLine("\nPress enter to enjoy your drink");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.ResetColor();
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.Clear();
                        Console.WriteLine("You don't have mix! Press enter to keep looking");
                        Console.ReadLine();
                        Kitchen2();
                    }
                }
                else
                {
                    Console.ResetColor();
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Clear();
                    Console.WriteLine("Incorrect input! Press enter...");
                    Console.ReadLine();
                    Kitchen2();
                }
            }
            else if (input == "B")
            {
                Coffee.ObtainMocha();
                Kitchen2();

            }
            else if (input == "C")
            {
                Coffee.ObtainCaramel();
                Kitchen2();

            }
            else if (input == "D")
            {
                Coffee.ObtainVanilla();
                Kitchen2();
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Incorrect input! Press enter...");
                Console.ReadLine();
                Kitchen2();
            }
        }
        public static void Joe()
        {
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.WriteLine(Graphics.JoesRoom);
            Console.WriteLine("You eneter the room only to discover it's not a normal room, but an entire functioning cafe! \nGeez, your roommate takes his job seriously. Behind the counter is your roommate joe!\n\n");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Barista Joe = new Barista("Joe", "Coffee", "Barista", 500);
            Joe.AboutRoommate();
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n'Hey " + Player.CharacterName + "! What's up?'");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n\nA) Skip the small talk and show me the menu!  B) Your haircut looks nice!");
            string input = "";
            input = Console.ReadLine();
            input = input.ToUpper();
            if(input == "A")
            {
                Barista.TakeOrder();
            }
            else if(input == "B")
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Console.WriteLine(Graphics.JoesRoom);
                Player.Inventory.Add("Empty tip jar");
                Console.WriteLine("Joe blushes!");
                Console.WriteLine("\n\n'Oh my...hehe oh my goodness! You're such a good pal! Here's all the money from the tip jar on me!'");
                Console.WriteLine("\nJoe gifted you the tip jar...which was empty. But you got a jar!");
                Console.WriteLine("\n\n'Now...what would you like to order?'");
                Console.WriteLine("Press enter to order coffee...");
                Console.ReadLine();
                Barista.TakeOrder();
            }
            else
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Console.WriteLine("Incorrect input! Press enter...");
                Console.ReadLine();
                Game.Joe();

            }

        }
        public static void WrapUp()
        {
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.WriteLine("You did it! The coffee is secured! \nYou feel your headache slowly going away...at least until the next one HAHA!");
            Console.WriteLine("\n\nFinal Stats:");
            Console.WriteLine("------------");
            Console.Write("Your final bank account is $");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(Player.PlayerTotal);
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("! ");
            if(Player.PlayerTotal < 0)
            {
                Console.WriteLine("You went into debt for coffee...you're an idiot");
            }
            Console.WriteLine("\n\nThe objects you've obtained are: ");
            Console.WriteLine("---------------------------------");
            foreach (string item in Player.Inventory)
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine(item);
            }
            if (Player.InventoryAmount == 0)
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("Nothing");
            }
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\nThank you for playing! Press enter to escape!");
        }
    }
}
