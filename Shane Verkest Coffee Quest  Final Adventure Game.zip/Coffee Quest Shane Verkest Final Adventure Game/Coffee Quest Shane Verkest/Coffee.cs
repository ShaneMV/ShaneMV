﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Coffee_Quest_Shane_Verkest
{
    class Coffee
    {
        public static double [] CoffeePrice = {3.50, 5.00, 6.00, 100};
        public static string Menu = "Menu.txt";
        public static string MenuContent = "(Empty File)";

        public static void ReadMenu()
        {

            if (File.Exists(Menu))
            {
             MenuContent = File.ReadAllText(Menu);
            }

            Console.WriteLine(MenuContent);
        }

        public static void ObtainMocha()
        {

            Console.Clear();
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Player.InventoryAmount++;
            Player.Inventory.Add("Mocha Mix");
            Console.Clear();
            Console.Write("You discovered the ");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("MOCHA");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write(" coffee mix!");
            Console.WriteLine("\n\nPress enter...");
            Console.ReadLine();
        }
        
        public static void ObtainCaramel()
        {
            Console.Clear();
            Player.InventoryAmount++;
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Player.Inventory.Add("Caramel Mix");
            Console.Write("You discovered the ");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("CARAMEL");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write(" coffee mix!");
            Console.WriteLine("\n\nPress enter...");
            Console.ReadLine();
        }
        public static void ObtainVanilla()
        {
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Player.InventoryAmount++;
            Player.Inventory.Add("Vanilla Mix");
            Console.Clear();
            Console.Write("You discovered the ");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("VANILLA");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write(" coffee mix!");
            Console.WriteLine("\n\nPress enter...");
            Console.ReadLine();
        }

    }
}
