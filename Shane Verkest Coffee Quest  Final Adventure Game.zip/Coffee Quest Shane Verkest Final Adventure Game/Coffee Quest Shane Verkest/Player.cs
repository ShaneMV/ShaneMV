﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Coffee_Quest_Shane_Verkest
{
    class Player
    {
        public static double PlayerMoney = 5;
        public static double PlayerTotal;
        public static string CharacterName = "";
        public static List<string> Inventory = new List<String>();
        public static int InventoryAmount;
        public static void CreatePlayer()
        {
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.WriteLine("Before we begin...what is your name?");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            CharacterName = Console.ReadLine();
            Console.Clear();
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("Oh right! Your name is ");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write(CharacterName);
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("! How could you forget?\n");
            Console.WriteLine("Press enter to wake up...");
            Console.ReadLine();

        }
    }
}
