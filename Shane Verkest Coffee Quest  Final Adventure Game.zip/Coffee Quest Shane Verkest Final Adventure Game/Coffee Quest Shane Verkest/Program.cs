﻿/*COFFEE QUEST: BY SHANE VERKEST
 * 11/9/20
 * Created with the help of lessons from ProgrammingIsFun.com
 * The coffee menu that reads from an external file was made with the help of Programming is fun.Com
 * The inheritance and constructors used in this game were made with the help of the in-class Inheritance Demo as a reference
 */
using System;
using System.IO;

namespace Coffee_Quest_Shane_Verkest
{
    class Program
    {
        static void Main()
        {
            Console.Title = "COFFEE QUEST";
            Console.WindowHeight = Console.LargestWindowHeight - 17;
            Console.WindowWidth = Console.LargestWindowWidth - 90;
            Game.StartGame();
            Player.CreatePlayer();
            Game.ChoiceOne();
            Game.WrapUp();
        }
    }
}
