﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Coffee_Quest_Shane_Verkest
{
    public class Jock : Roommate
    {
        public Jock(string _Name, string _Major, string _Job, int BankAccount, int MuscleLevel) : base( _Name, _Major, _Job, BankAccount)
        {
            this.Name = _Name;
            this.Major = _Major;
            this.Job = _Job;
            this.BankAccount = BankAccount;
            this.MuscleLevel = 0;

        }
        public static void Bully()
        {
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n\n'Hey, punk! Trying to get some coffee? So lame! What's stopping me from pumbling you right now?'");
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\nA) I can take you punk!  B) Did you get a haircut? It looks so good!");
            string input = "";
            input = Console.ReadLine();
            input = input.ToUpper();
            if(input == "A")
            {
                Steal();
            }
            else if(input == "B")
            {
                Give();
            }
            else
            {
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.White;
                Console.Clear();
                Console.WriteLine("Incorrect input! Press enter...");
                Console.ReadLine();
                Game.Kitchen();
            }
        }
        public static void Steal()
        {
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Console.WriteLine(Graphics.Bully);
            Player.PlayerTotal = Player.PlayerMoney - 3.0;
            Console.WriteLine("'That's it punk! I'm gonna steal your lunch money!'");
            Console.WriteLine("\nHe just stole $3! But afterwards he walks away, leaving the kitchen door wide open.");
            Console.WriteLine("\nPress enter to enter the kitchen...");
            Console.ReadLine();

        }
        public static void Give()
        {
            Console.ResetColor();
            Console.ForegroundColor = ConsoleColor.White;
            Console.Clear();
            Player.PlayerTotal = Player.PlayerMoney + 2.0;
            Player.InventoryAmount++;
            Player.Inventory.Add("Muscle Milk Coupon");
            Console.WriteLine(Graphics.Bully);
            Console.WriteLine("'You know what kid...you're pretty nice after all! Here's some pocket change for your little coffee quest...'");
            Console.ResetColor();
            Console.WriteLine("\nHe gives you a coupon for muscle milk and $2! How useless! He steps back and lets you enter the kitchen!");
            Console.WriteLine("\nPress enter to head to the kitchen...");
            Console.ReadLine();
        }
    }
}
